//****************************************************************************

// Author: Mark Mauro

// Section: 02

// Chapter 8, In class assignment: Arrays

//*****************************************************************************

import java.util.Random;

public class number_three {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Random r = new Random();
		
		
		int[] a = new int[11];
		
		for(int i = 1; i <= a.length; i++) {
			
			int random =  r.nextInt(100) + 1;
			a[i] = random;
			System.out.println(a[i]);
			
		}
		
		
	}

}
