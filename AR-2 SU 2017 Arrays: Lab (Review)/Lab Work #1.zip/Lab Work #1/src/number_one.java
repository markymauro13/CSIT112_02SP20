//****************************************************************************

// Author: Mark Mauro

// Section: 02

// Chapter 8, In class assignment: Arrays

//*****************************************************************************


public class number_one {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = {1,2,3,4,5};
	}

}
